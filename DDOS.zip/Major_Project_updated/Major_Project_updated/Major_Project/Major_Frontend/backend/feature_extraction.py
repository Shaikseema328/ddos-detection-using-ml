
import pyshark
import asyncio
import pandas as pd
from collections import defaultdict

def aggregate_sessions(pcap_file):
    # Create an event loop manually
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    
    capture = pyshark.FileCapture(pcap_file, use_json=True, include_raw=True)
    session_data = defaultdict(list)

    # Process each packet in the capture
    for packet in capture:
        try:
            src_ip = packet.ip.src
            dst_ip = packet.ip.dst
            protocol = packet.transport_layer
            src_port = getattr(packet[packet.transport_layer], 'srcport', None)
            dst_port = getattr(packet[packet.transport_layer], 'dstport', None)
            time = float(packet.sniff_time.timestamp())
            bytes_sent = int(packet.length)
            session_key = (src_ip, dst_ip, protocol, src_port, dst_port)

            session_data[session_key].append({
                'src_ip': src_ip,
                'dst_ip': dst_ip,
                'bytes_sent': bytes_sent,
                'time': time
            })
        except AttributeError:
            continue
    
    capture.close()

    session_features = []
    for session_key, packets in session_data.items():
        src_ip, dst_ip, protocol, src_port, dst_port = session_key
        session_count = len(packets)
        srv_count = sum(1 for pkt in packets if pkt['dst_ip'] == dst_ip)
        same_srv_rate = srv_count / session_count if session_count > 0 else 0
        total_bytes = sum(p['bytes_sent'] for p in packets)
        duration = packets[-1]['time'] - packets[0]['time'] if session_count > 1 else 0
        src_bytes = sum(pkt['bytes_sent'] for pkt in packets if pkt['src_ip'] == src_ip)
        dst_bytes = sum(pkt['bytes_sent'] for pkt in packets if pkt['dst_ip'] == src_ip)
        diff_srv_rate = len(set([pkt['dst_ip'] for pkt in packets])) / session_count if session_count > 0 else 0
        srv_serror_rate = 0  # SYN/RST flag-based rate (can be calculated similarly to serror_rate)
        srv_diff_host_rate = len(set([pkt['src_ip'] for pkt in packets])) / srv_count if srv_count > 0 else 0

        # Create a dictionary of session-level features
        features = {
            'duration': duration,
            'src_bytes': src_bytes,
            'dst_bytes': dst_bytes,
            'land': 0,
            'wrong_fragment': 0,
            'su_attempted': 0,
            'num_outbound_cmds': 0,
            'is_host_login': 0,
            'count': session_count,
            'srv_count': srv_count,
            'serror_rate': 0,
            'srv_serror_rate': srv_serror_rate,
            'same_srv_rate': same_srv_rate,
            'diff_srv_rate': diff_srv_rate,
            'srv_diff_host_rate': srv_diff_host_rate,
            
        }

        session_features.append(features)

    # Return the DataFrame with aggregated session features
    return pd.DataFrame(session_features)
