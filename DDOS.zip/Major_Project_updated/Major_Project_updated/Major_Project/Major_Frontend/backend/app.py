
import os
from flask import Flask, render_template, request, redirect
from werkzeug.utils import secure_filename
from feature_extraction import aggregate_sessions
import pandas as pd
from model_loader import load_model

app = Flask(__name__, template_folder='../frontend/templates')

# Configurations for file upload
UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'uploads')
ALLOWED_EXTENSIONS = {'pcap', 'pcapng'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ensure the uploads directory exists
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Helper function to check allowed file extensions
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process_file', methods=['POST'])
def process_file():
    # Check if the file is in the form
    if 'file' not in request.files:
        return redirect(request.url)

    file = request.files['file']
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        
        # Save the uploaded file
        file.save(file_path)

        # Get selected algorithm and attack type
        algorithm = request.form['algorithm']
        attack_type = request.form['attack']

        # Process the uploaded file and get features
        try:
            # Get the features using aggregate_sessions from feature_extraction
            df = aggregate_sessions(file_path)

            # Pass features, algorithm, and attack type to form.html
            features = df.to_dict(orient='records')[0]  # Convert first row of the dataframe to dictionary

            return render_template('form.html', features=features, algorithm=algorithm, attack_type=attack_type)

        except Exception as e:
            return f"Error processing the file: {str(e)}"
    
    return "Invalid file type. Please upload a .pcap or .pcapng file."

@app.route('/result', methods=['POST'])
def result():
    # Extract form data
    feature_values = request.form.to_dict()
    algorithm = feature_values.pop('algorithm')
    attack_type = feature_values.pop('attack_type')

    # Convert to DataFrame
    df = pd.DataFrame([feature_values])
    df = df.apply(pd.to_numeric)  # Ensure correct data type

    # Load and predict using the selected model
    model = load_model(attack_type, algorithm)

    # Debugging: Print the type of model to see what was loaded
    print(f"Loaded model type: {type(model)}")

    # Check if the model has 'predict' method
    if hasattr(model, 'predict'):
        prediction = model.predict(df)
    else:
        return f"Loaded model does not have a 'predict' method. It's of type {type(model)}."

    # Display result
    result_text = "Attack Detected" if prediction[0] == 1 else "No Attack"
    
    return render_template('result.html', result=result_text)

if __name__ == "__main__":
    app.run(debug=True)
